﻿using ExchangeRateUpdater.Services;
using ExchangeRateUpdater.Features.ExchangeRates.Models;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using ZiggyCreatures.Caching.Fusion;
using System.Net.Http.Json;

namespace ExchangeRateUpdater.Unit.Tests;
public class APIClientTests
{
    [Fact]
    public async Task GetExchangeRatesDailyAsync_ReturnsRates()
    {
        // Arrange
        var sampleData = new ExchangeRateResponseWrapper
        {
            Rates = new()
            {
                new ExchangeRateResponse { CurrencyCode = "USD", Rate = 22.5m }
            }
        };

        var response = new HttpResponseMessage(System.Net.HttpStatusCode.OK)
        {
            Content = JsonContent.Create(sampleData)
        };

        var handler = new MockHttpMessageHandler(response);
        var httpClient = new HttpClient(handler)
        {
            BaseAddress = new Uri("https://api.example.com/")
        };

        var cacheMock = new Mock<IFusionCache>();

        cacheMock
            .Setup(x => x.GetOrSetAsync(
                It.IsAny<string>(),
                It.IsAny<Func<CancellationToken, Task<List<ExchangeRateResponse>>>>(),
                It.IsAny<FusionCacheEntryOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(sampleData.Rates);


        var logger = NullLogger<APIClient>.Instance;

        var client = new APIClient(httpClient, cacheMock.Object, logger);

        // Act
        var result = await client.GetExchangeRatesDailyAsync(null, null, default);

        // Assert
        Assert.Single(result);
        Assert.Equal("USD", result[0].CurrencyCode);
        Assert.Equal(22.5m, result[0].Rate);
    }
}
