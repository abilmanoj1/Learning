# Mews backend developer task

We are focused on multiple backend frameworks at Mews. Depending on the job position you are applying for, you can choose among the following:

* [.NET](DotNet.md)
* [Ruby on Rails](RoR.md)
