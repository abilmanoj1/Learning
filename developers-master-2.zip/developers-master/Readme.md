Mews repository for external-facing resources.
